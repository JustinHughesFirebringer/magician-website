(()=>{var e={};e.id=404,e.ids=[404],e.modules={517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4300:e=>{"use strict";e.exports=require("buffer")},6113:e=>{"use strict";e.exports=require("crypto")},2361:e=>{"use strict";e.exports=require("events")},7147:e=>{"use strict";e.exports=require("fs")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},1808:e=>{"use strict";e.exports=require("net")},2037:e=>{"use strict";e.exports=require("os")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},4404:e=>{"use strict";e.exports=require("tls")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},3739:()=>{},3778:(e,t,s)=>{"use strict";s.r(t),s.d(t,{headerHooks:()=>E,originalPathname:()=>q,patchFetch:()=>O,requestAsyncStorage:()=>m,routeModule:()=>l,serverHooks:()=>g,staticGenerationAsyncStorage:()=>d,staticGenerationBailout:()=>R});var r={};s.r(r),s.d(r,{GET:()=>p,dynamic:()=>u});var i=s(884),a=s(6132),n=s(1040),c=s(5798),o=s(8988);let u="force-dynamic";async function p(e){try{let{searchParams:t}=new URL(e.url),s=t.get("state")||void 0,r=t.get("city")||void 0,i=t.get("service")||void 0,a=t.get("query")||void 0,n=parseInt(t.get("page")||"1"),u=parseInt(t.get("limit")||"10"),p=await (0,o.pB)({state:s,city:r,service:i,query:a,page:n,limit:u});return c.Z.json(p)}catch(e){return console.error("Error searching magicians:",e),c.Z.json({error:"Internal server error"},{status:500})}}let l=new i.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/magicians/route",pathname:"/api/magicians",filename:"route",bundlePath:"app/api/magicians/route"},resolvedPagePath:"C:\\Users\\bigre\\CascadeProjects\\magician-website\\src\\app\\api\\magicians\\route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:m,staticGenerationAsyncStorage:d,serverHooks:g,headerHooks:E,staticGenerationBailout:R}=l,q="/api/magicians/route";function O(){return(0,n.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:d})}},8988:(e,t,s)=>{"use strict";s.d(t,{mB:()=>c,JC:()=>u,z0:()=>n,ok:()=>o,pB:()=>a});var r=s(1346);let i={sql:r.i6};async function a(e){let{state:t,city:s,service:r,query:a,page:n=1,limit:c=10}=e,o=[],u=[],p=1;t&&(o.push(`state = $${p}`),u.push(t),p++),s&&(o.push(`city ILIKE $${p}`),u.push(`%${s}%`),p++),r&&(o.push(`$${p} = ANY(services)`),u.push(r),p++),a&&(o.push(`(
      name ILIKE $${p} OR
      business_name ILIKE $${p} OR
      description ILIKE $${p}
    )`),u.push(`%${a}%`),p++);let l=await i.sql`
    WITH filtered_magicians AS (
      ${o.length>0?i.sql`SELECT * FROM magicians WHERE ${i.sql.join(o,i.sql` AND `)}`:i.sql`SELECT * FROM magicians`}
    ),
    counted_magicians AS (
      SELECT COUNT(*) as total_count FROM filtered_magicians
    )
    SELECT m.*, c.total_count
    FROM filtered_magicians m, counted_magicians c
    ORDER BY m.rating DESC NULLS LAST, m.review_count DESC NULLS LAST
    LIMIT ${c}
    OFFSET ${(n-1)*c}
  `;return{magicians:l.rows.map(e=>({...e,createdAt:new Date(e.createdAt),updatedAt:new Date(e.updatedAt)})),total:Number(l.rows[0]?.total_count||0),currentPage:n,pageSize:c,totalPages:Math.ceil((Number(l.rows[0]?.total_count)||0)/c)}}async function n(e){let t=await i.sql`
    SELECT * FROM magicians
    WHERE id = ${e}
  `;return t.rows[0]?{...t.rows[0],createdAt:new Date(t.rows[0].createdAt),updatedAt:new Date(t.rows[0].updatedAt)}:null}async function c(){let e=await i.sql`
    SELECT service, COUNT(*)::int as count
    FROM magicians, jsonb_array_elements_text(services) as service
    GROUP BY service
    ORDER BY count DESC
  `,t=await i.sql`
    SELECT state, city, COUNT(*)::int as magician_count
    FROM magicians
    GROUP BY state, city
    ORDER BY magician_count DESC
  `;return{services:e.rows,locations:t.rows}}async function o(){let e=await i.sql`
    SELECT service, COUNT(*)::int as count
    FROM magicians, jsonb_array_elements_text(services) as service
    GROUP BY service
    ORDER BY count DESC
  `;return e.rows}async function u(){let e=await i.sql`
    SELECT state, city, COUNT(*)::int as magician_count
    FROM magicians
    GROUP BY state, city
    ORDER BY magician_count DESC
  `;return e.rows}}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[271,346,107],()=>s(3778));module.exports=r})();