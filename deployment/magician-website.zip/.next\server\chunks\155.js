exports.id=155,exports.ids=[155],exports.modules={3739:()=>{},3265:(e,s,a)=>{Promise.resolve().then(a.t.bind(a,3579,23)),Promise.resolve().then(a.t.bind(a,619,23)),Promise.resolve().then(a.t.bind(a,1459,23)),Promise.resolve().then(a.t.bind(a,3456,23)),Promise.resolve().then(a.t.bind(a,847,23)),Promise.resolve().then(a.t.bind(a,7303,23))},7347:()=>{},3819:(e,s,a)=>{"use strict";a.r(s),a.d(s,{default:()=>l});var t=a(3854),i=a(3708);/**
 * @license lucide-react v0.294.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let r=(0,i.Z)("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);var n=a(1018),c=a(4218);function l({services:e,locations:s,initialValues:a}){let i=(0,n.useRouter)(),l=(0,n.useSearchParams)(),[o,d]=(0,c.useState)(a?.query||l.get("query")||""),[u,m]=(0,c.useState)(a?.location||l.get("location")||""),[h,g]=(0,c.useState)(a?.service||l.get("service")||"");return(0,t.jsxs)("div",{className:"relative w-full max-w-2xl mx-auto",children:[t.jsx("div",{className:"magic-glow absolute -inset-1 opacity-50"}),t.jsx("form",{onSubmit:e=>{e.preventDefault();let s=new URLSearchParams(l.toString());o?s.set("query",o):s.delete("query"),u?s.set("location",u):s.delete("location"),h?s.set("service",h):s.delete("service"),i.push(`/search?${s.toString()}`)},className:"relative bg-white rounded-lg shadow-md p-4",children:(0,t.jsxs)("div",{className:"flex flex-col md:flex-row gap-4",children:[t.jsx("div",{className:"flex-1",children:t.jsx("input",{type:"text",value:o,onChange:e=>d(e.target.value),placeholder:"Search magicians...",className:"w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"})}),t.jsx("div",{className:"flex-1",children:(0,t.jsxs)("select",{value:u,onChange:e=>m(e.target.value),className:"w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",children:[t.jsx("option",{value:"",children:"Any Location"}),s.map(({city:e,state:s})=>(0,t.jsxs)("option",{value:`${e}, ${s}`,children:[e,", ",s]},`${e}, ${s}`))]})}),t.jsx("div",{className:"flex-1",children:(0,t.jsxs)("select",{value:h,onChange:e=>g(e.target.value),className:"w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent",children:[t.jsx("option",{value:"",children:"Any Service"}),e.map(({service:e})=>t.jsx("option",{value:e,children:e},e))]})}),t.jsx("button",{type:"submit",className:"px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2",children:t.jsx(r,{className:"w-5 h-5"})})]})}),t.jsx("div",{className:"magic-sparkle top-0 left-1/4 delay-75"}),t.jsx("div",{className:"magic-sparkle bottom-0 left-1/3 delay-150"}),t.jsx("div",{className:"magic-sparkle top-1/2 right-1/4 delay-300"})]})}},9113:(e,s,a)=>{"use strict";a.r(s),a.d(s,{default:()=>c,metadata:()=>n});var t=a(4656),i=a(186),r=a.n(i);a(5023);let n={title:"Find a Magician United States",description:"Find professional magicians in your area across the United States"};function c({children:e}){return t.jsx("html",{lang:"en",children:(0,t.jsxs)("body",{className:r().className,children:[t.jsx("header",{className:"bg-white shadow-md",children:t.jsx("nav",{className:"container mx-auto px-4 py-6",children:(0,t.jsxs)("div",{className:"flex justify-between items-center",children:[t.jsx("h1",{className:"text-2xl font-bold",children:"Find a Magician"}),(0,t.jsxs)("div",{className:"space-x-6",children:[t.jsx("a",{href:"/",className:"hover:text-blue-600",children:"Home"}),t.jsx("a",{href:"/magicians",className:"hover:text-blue-600",children:"Magicians"}),t.jsx("a",{href:"/locations",className:"hover:text-blue-600",children:"Locations"}),t.jsx("a",{href:"/contact",className:"hover:text-blue-600",children:"Contact"})]})]})})}),t.jsx("main",{children:e}),t.jsx("footer",{className:"bg-gray-800 text-white py-8",children:t.jsx("div",{className:"container mx-auto px-4",children:t.jsx("p",{className:"text-center",children:"\xa9 2024 Find a Magician United States. All rights reserved."})})})]})})}},5006:(e,s,a)=>{"use strict";a.d(s,{ZP:()=>l});var t=a(5153);let i=(0,t.createProxy)(String.raw`C:\Users\bigre\CascadeProjects\magician-website\src\components\SearchForm.tsx`),{__esModule:r,$$typeof:n}=i,c=i.default,l=c},8988:(e,s,a)=>{"use strict";a.d(s,{mB:()=>c,JC:()=>o,z0:()=>n,ok:()=>l,pB:()=>r});var t=a(1346);let i={sql:t.i6};async function r(e){let{state:s,city:a,service:t,query:r,page:n=1,limit:c=10}=e,l=[],o=[],d=1;s&&(l.push(`state = $${d}`),o.push(s),d++),a&&(l.push(`city ILIKE $${d}`),o.push(`%${a}%`),d++),t&&(l.push(`$${d} = ANY(services)`),o.push(t),d++),r&&(l.push(`(
      name ILIKE $${d} OR
      business_name ILIKE $${d} OR
      description ILIKE $${d}
    )`),o.push(`%${r}%`),d++);let u=await i.sql`
    WITH filtered_magicians AS (
      ${l.length>0?i.sql`SELECT * FROM magicians WHERE ${i.sql.join(l,i.sql` AND `)}`:i.sql`SELECT * FROM magicians`}
    ),
    counted_magicians AS (
      SELECT COUNT(*) as total_count FROM filtered_magicians
    )
    SELECT m.*, c.total_count
    FROM filtered_magicians m, counted_magicians c
    ORDER BY m.rating DESC NULLS LAST, m.review_count DESC NULLS LAST
    LIMIT ${c}
    OFFSET ${(n-1)*c}
  `;return{magicians:u.rows.map(e=>({...e,createdAt:new Date(e.createdAt),updatedAt:new Date(e.updatedAt)})),total:Number(u.rows[0]?.total_count||0),currentPage:n,pageSize:c,totalPages:Math.ceil((Number(u.rows[0]?.total_count)||0)/c)}}async function n(e){let s=await i.sql`
    SELECT * FROM magicians
    WHERE id = ${e}
  `;return s.rows[0]?{...s.rows[0],createdAt:new Date(s.rows[0].createdAt),updatedAt:new Date(s.rows[0].updatedAt)}:null}async function c(){let e=await i.sql`
    SELECT service, COUNT(*)::int as count
    FROM magicians, jsonb_array_elements_text(services) as service
    GROUP BY service
    ORDER BY count DESC
  `,s=await i.sql`
    SELECT state, city, COUNT(*)::int as magician_count
    FROM magicians
    GROUP BY state, city
    ORDER BY magician_count DESC
  `;return{services:e.rows,locations:s.rows}}async function l(){let e=await i.sql`
    SELECT service, COUNT(*)::int as count
    FROM magicians, jsonb_array_elements_text(services) as service
    GROUP BY service
    ORDER BY count DESC
  `;return e.rows}async function o(){let e=await i.sql`
    SELECT state, city, COUNT(*)::int as magician_count
    FROM magicians
    GROUP BY state, city
    ORDER BY magician_count DESC
  `;return e.rows}},5023:()=>{}};