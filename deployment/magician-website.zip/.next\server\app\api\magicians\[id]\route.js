(()=>{var e={};e.id=77,e.ids=[77],e.modules={517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4300:e=>{"use strict";e.exports=require("buffer")},6113:e=>{"use strict";e.exports=require("crypto")},2361:e=>{"use strict";e.exports=require("events")},7147:e=>{"use strict";e.exports=require("fs")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},1808:e=>{"use strict";e.exports=require("net")},2037:e=>{"use strict";e.exports=require("os")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},4404:e=>{"use strict";e.exports=require("tls")},7310:e=>{"use strict";e.exports=require("url")},9796:e=>{"use strict";e.exports=require("zlib")},3739:()=>{},8525:(e,t,r)=>{"use strict";r.r(t),r.d(t,{headerHooks:()=>E,originalPathname:()=>R,patchFetch:()=>O,requestAsyncStorage:()=>l,routeModule:()=>p,serverHooks:()=>m,staticGenerationAsyncStorage:()=>d,staticGenerationBailout:()=>g});var s={};r.r(s),r.d(s,{GET:()=>o});var i=r(884),a=r(6132),n=r(1040),c=r(5798),u=r(8988);async function o(e,{params:t}){try{let e=await (0,u.z0)(t.id);if(!e)return c.Z.json({error:"Magician not found"},{status:404});return c.Z.json(e)}catch(e){return console.error("Error fetching magician:",e),c.Z.json({error:"Internal server error"},{status:500})}}let p=new i.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/magicians/[id]/route",pathname:"/api/magicians/[id]",filename:"route",bundlePath:"app/api/magicians/[id]/route"},resolvedPagePath:"C:\\Users\\bigre\\CascadeProjects\\magician-website\\src\\app\\api\\magicians\\[id]\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:l,staticGenerationAsyncStorage:d,serverHooks:m,headerHooks:E,staticGenerationBailout:g}=p,R="/api/magicians/[id]/route";function O(){return(0,n.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:d})}},8988:(e,t,r)=>{"use strict";r.d(t,{mB:()=>c,JC:()=>o,z0:()=>n,ok:()=>u,pB:()=>a});var s=r(1346);let i={sql:s.i6};async function a(e){let{state:t,city:r,service:s,query:a,page:n=1,limit:c=10}=e,u=[],o=[],p=1;t&&(u.push(`state = $${p}`),o.push(t),p++),r&&(u.push(`city ILIKE $${p}`),o.push(`%${r}%`),p++),s&&(u.push(`$${p} = ANY(services)`),o.push(s),p++),a&&(u.push(`(
      name ILIKE $${p} OR
      business_name ILIKE $${p} OR
      description ILIKE $${p}
    )`),o.push(`%${a}%`),p++);let l=await i.sql`
    WITH filtered_magicians AS (
      ${u.length>0?i.sql`SELECT * FROM magicians WHERE ${i.sql.join(u,i.sql` AND `)}`:i.sql`SELECT * FROM magicians`}
    ),
    counted_magicians AS (
      SELECT COUNT(*) as total_count FROM filtered_magicians
    )
    SELECT m.*, c.total_count
    FROM filtered_magicians m, counted_magicians c
    ORDER BY m.rating DESC NULLS LAST, m.review_count DESC NULLS LAST
    LIMIT ${c}
    OFFSET ${(n-1)*c}
  `;return{magicians:l.rows.map(e=>({...e,createdAt:new Date(e.createdAt),updatedAt:new Date(e.updatedAt)})),total:Number(l.rows[0]?.total_count||0),currentPage:n,pageSize:c,totalPages:Math.ceil((Number(l.rows[0]?.total_count)||0)/c)}}async function n(e){let t=await i.sql`
    SELECT * FROM magicians
    WHERE id = ${e}
  `;return t.rows[0]?{...t.rows[0],createdAt:new Date(t.rows[0].createdAt),updatedAt:new Date(t.rows[0].updatedAt)}:null}async function c(){let e=await i.sql`
    SELECT service, COUNT(*)::int as count
    FROM magicians, jsonb_array_elements_text(services) as service
    GROUP BY service
    ORDER BY count DESC
  `,t=await i.sql`
    SELECT state, city, COUNT(*)::int as magician_count
    FROM magicians
    GROUP BY state, city
    ORDER BY magician_count DESC
  `;return{services:e.rows,locations:t.rows}}async function u(){let e=await i.sql`
    SELECT service, COUNT(*)::int as count
    FROM magicians, jsonb_array_elements_text(services) as service
    GROUP BY service
    ORDER BY count DESC
  `;return e.rows}async function o(){let e=await i.sql`
    SELECT state, city, COUNT(*)::int as magician_count
    FROM magicians
    GROUP BY state, city
    ORDER BY magician_count DESC
  `;return e.rows}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[271,346,107],()=>r(8525));module.exports=s})();